1. Run the program using batch file run.bat.
2. To make the Middleware send messages to the Network, press the "return" key ONCE in each of the command windows for the Middleware.
